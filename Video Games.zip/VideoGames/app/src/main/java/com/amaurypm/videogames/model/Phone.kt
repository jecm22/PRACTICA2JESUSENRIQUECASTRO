package com.amaurypm.videogames.model

/**
 * Creado por Amaury Perea Matsumura el 21/10/22
 */
data class Phone(
    var id: Int,
    var modelo: String,
    var marca: String,
    var capacidad: String,

)
